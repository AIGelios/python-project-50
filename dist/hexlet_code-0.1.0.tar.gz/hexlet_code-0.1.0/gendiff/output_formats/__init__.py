from .stylish_output import make_stylish
from .plain_output import make_plain
from .json_output import make_json
from .yaml_output import make_yaml
